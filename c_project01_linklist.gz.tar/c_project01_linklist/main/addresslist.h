#pragma once
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include "mystring.h"

typedef char str_ch;    //存储字符串数据
typedef short sm_num;   //存储较小的整型数字

typedef struct student
{   
    str_ch id[10];
    str_ch name[15];
    sm_num age;
    str_ch tel[12];
    struct student *next;
}student;

//菜单
void menu();
//初始化存储信息链表
student *StudentListCreate();
//初始化读如通讯录信息
void StudentListInit(student *head);
//修改指定用户的信息
void StudentListUpdate(student *head);
//删除指定用户的信息
void StudentListDelete(student *head);
//浏览通讯录信息
void StudentListPrint(student *head);
//添加用户信息
void StudentListInsert(student *head);
//检索用户信息
void StudentListRetrieve(student *head);
//保存所有的更改到文件中
void SaveInformation(student *head);
//说明书
void Instructions();
//程序结束前，清空单链表
void StudentListClear(student **head);