#include "addresslist.h"

int main(int argc, char const *argv[])
{
    int choice;

    student *head = StudentListCreate();
    
    StudentListInit(head);

    while (1)
    {
        menu();
        printf("input>>>");
        scanf("%d", &choice);
        switch (choice)
        {
        case 1:
            StudentListUpdate(head);
            break;
        case 2:
            StudentListDelete(head);
            break;
        case 3:
            StudentListPrint(head);
            break;
        case 4:
            StudentListInsert(head);
            break;
        case 5:
            StudentListRetrieve(head);
            break;
        case 6:
            SaveInformation(head);
            break;
        case 7:
            Instructions();
            break;
        case 8:
            StudentListClear(&head);
            exit(0);
            break;
        default:
            system("clear");
            printf("输入有误，请重新输入！\n");
            sleep(1);
            break;
        }
    }

    return 0;
}
